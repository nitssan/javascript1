//-------------------var-----------
var tester = "hey hi"; function newFunction() { var hello = "hello"; } console.log(hello)



//---------------var variables can be re-declared and updated

var greeter = "hey hi"; var greeter = "say Hello instead";

//----------Hoisting of var

console.log (greeter); var greeter = "say hello"


//---------Problem with var

var greeter = "hey hi"; var times = 4; if (times > 3) { var greeter = "say Hello instead"; } console.log(greeter) 

//-----------------------
//-------------Let

//----let is block scoped

let greeting = "say Hi"; let times = 4; if (times > 3) { let hello = "say Hello instead"; console.log(hello);// "say Hello instead" } console.log(hello)

//----------let can be updated but not re-declared.

let greeting = "say Hi"; greeting = "say Hello instead";


<!--it will return error          -->

<!--Hoisting of let

Just like  var, let declarations are hoisted to the top. Unlike var which is initialized as undefined, the let keyword is not initialized. So if you try to use a let variable before declaration, you'll get a Reference Error.-->

<!--const-->
<!--Const

Variables declared with the const maintain constant values. const declarations share some similarities with let declarations.

-->

<!--const declarations are block scoped-->

<!--const cannot be updated or re-declared-->

const greeting = { message: "say Hi", times: 4 }


<!--Hoisting of const

Just like let, const declarations are hoisted to the top but are not initialized.-->

<!--difference in all above -->
/*var declarations are globally scoped or function scoped while let and const are block scoped.

var variables can be updated and re-declared within its scope; let variables can be updated but not re-declared; const variables can neither be updated nor re-declared.

They are all hoisted to the top of their scope. But while var variables are initialized with undefined, let and const variables are not initialized.

While var and let can be declared without being initialized, const must be initialized during declaration.*/













